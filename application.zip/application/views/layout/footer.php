<footer id="footer" class="footer">
    <div class="copyright">
        &copy; 2024. Copyright <strong><span>PT. Kalimantan Prima Persada</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
        Developed by <a href="#">Jeremy Nainggolan</a>
    </div>
</footer><!-- End Footer -->