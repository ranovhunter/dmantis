<?php

defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Rent_model
 * created by : Hunter Nainggolan <hunter.nainggolan@gmail.com>
 * date : April 04th, 2023
 */
class Rent_model extends MY_Model {

    function __construct() {
        parent::__construct();
        $this->set_table('rent');
        $this->set_view('view_rent');
    }

    /**
     * function add_data
     * to add data to rent table
     * @author hunter.nainggolan
     * @date April 4, 2023
     * @access public
     * 
     * @param array $data  
     * @return boolean
     */
    public function add_data($data) {
        $this->trans_begin();
        $this->insert($data);
        $this->insert_id = $this->get_insert_id();
        if ($this->trans_status()) {
            $this->trans_commit();
            return true;
        } else {
            $this->trans_rollback();
            return false;
        }
    }

    /**
     * edit_data
     * to change data in rent table
     * @author hunter.nainggolan
     * @date April 4, 2023
     * @access public
     * 
     * @param array $data
     * @param array $where 
     * @return boolean
     */
    public function edit_data($data, $where = null) {
        $this->trans_begin();
        $this->update($data, $where);
        if ($this->trans_status()) {
            $this->trans_commit();
            return true;
        } else {
            $this->trans_rollback();
            return false;
        }
    }

    /**
     * delete_data
     * to delete data from rent table
     * @author hunter.nainggolan
     * @date April 4, 2023
     * @access public
     * 
     * @param array $where
     * @return boolean
     */
    public function delete_data($where = null) {
        $this->trans_begin();
        $this->delete($where);
        if ($this->trans_status()) {
            $this->trans_commit();
            return true;
        } else {
            $this->trans_rollback();
            return false;
        }
    }

    /**
     * get_req_user_rent
     * to retrieve user data from rent table
     * @author hunter.nainggolan
     * @date July 10, 2024
     * @access public
     * 
     * @return array
     */
    public function get_req_user_rent() {
        $query = $this->db->query('call get_request_rent');
        $this->total_rows = $query->num_rows();
        return $query->result_array();
    }

    /**
     * get_appr_user_rent
     * to retrieve user data from rent table
     * @author hunter.nainggolan
     * @date July 10, 2024
     * @access public
     * 
     * @return array
     */
    public function get_appr_user_rent() {
        $query = $this->db->query('call get_approved_rent');
        $this->total_rows = $query->num_rows();
        return $query->result_array();
    }

    /**
     * get_active_user_rent
     * to retrieve user data from rent table
     * @author hunter.nainggolan
     * @date July 10, 2024
     * @access public
     * 
     * @return array
     */
    public function get_active_user_rent() {
        $query = $this->db->query('call get_active_rent');
        $this->total_rows = $query->num_rows();
        return $query->result_array();
    }

    /**
     * get_rent_by_qr
     * to retrieve user data from rent table
     * @author hunter.nainggolan
     * @date July 10, 2024
     * @access public
     * 
     * @return array
     */
    public function get_rent_by_qr($userid, $qrcode) {
        $query = $this->db->query("select * from view_rent where qrcode = '" . $qrcode . "' and rstatus=1 and rent_user='" . $userid . "' limit 0,1");
        return $query->result() == array() ? array() : $query->result()[0];
    }
}

/**
 * End of file rent_model.php
 * Location: ./application/models/rent_model.php
 */