<?php
$config['facebook']['appId'] = "2824483027562674"; // APP ID FROM FACEBOOK
   $config['facebook']['secret'] = "1510f1b248016d40aebce540a23c05e1"; // APP SECRET FROM FACEBOOK
   $config['facebook']['cookie'] = TRUE;
?>