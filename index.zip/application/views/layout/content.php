<section class="section">
    <div class="row">
        <?php echo $page; ?>
    </div>
</section>
