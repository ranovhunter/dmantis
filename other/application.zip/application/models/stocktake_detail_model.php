<?php

defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Stocktake_detail_model
 * created by : Hunter Nainggolan <hunter.nainggolan@gmail.com>
 * date : Oct 13th, 2022
 */
class Stocktake_detail_model extends MY_Model {

    function __construct() {
        parent::__construct();
        $this->set_table('stock_take_detail');
        $this->set_view('v_stock_take_detail');
    }

    /**
     * function add_data
     * to add data to site table
     * @author hunter.nainggolan
     * @date April 4, 2015
     * @access public
     * 
     * @param array $data  
     * @return boolean
     */
    public function add_data($data) {
        $this->trans_begin();
        $this->insert($data);
        $this->insert_id = $this->get_insert_id();
        if ($this->trans_status()) {
            $this->trans_commit();
            return true;
        } else {
            $this->trans_rollback();
            return false;
        }
    }

    /**
     * edit_data
     * to change data in site table
     * @author hunter.nainggolan
     * @date April 4, 2015
     * @access public
     * 
     * @param array $data
     * @param array $where 
     * @return boolean
     */
    public function edit_data($data, $where = null) {
        $this->trans_begin();
        $this->update($data, $where);
        if ($this->trans_status()) {
            $this->trans_commit();
            return true;
        } else {
            $this->trans_rollback();
            return false;
        }
    }

    /**
     * delete_data
     * to delete data from site table
     * @author hunter.nainggolan
     * @date April 4, 2015
     * @access public
     * 
     * @param array $where
     * @return boolean
     */
    public function delete_data($where = null) {
        $this->trans_begin();
        $this->delete($where);
        if ($this->trans_status()) {
            $this->trans_commit();
            return true;
        } else {
            $this->trans_rollback();
            return false;
        }
    }

}

/**
 * End of file stocktake_detail_model.php
 * Location: ./application/models/stocktake_detail_model.php
 */