<footer id="footer" class="footer">
    <div class="copyright">
        &copy; 2022. Copyright <strong><span>Younexa Indonesia</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
        Developed by <a href="#">Hunter Nainggolan</a>
    </div>
</footer><!-- End Footer -->