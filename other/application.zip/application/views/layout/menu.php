<!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">
    <ul class="sidebar-nav" id="sidebar-nav">
        <?php foreach ($listmenu as $row) { ?>
            <li class="nav-item">
                <a class="nav-link <?= $module == $row['name'] ? '' : 'collapsed'; ?>" href="<?= site_url($row['name']); ?>">
                    <i class="<?= $row['icon']; ?>"></i>
                    <span><?= ucfirst($row['name']); ?></span>
                </a>
            </li><!-- End Blank Page Nav -->
        <?php } ?>
    </ul>
</aside><!-- End Sidebar-->