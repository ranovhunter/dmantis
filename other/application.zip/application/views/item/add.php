<div class="card">
    <div class="card-body">
        <h5 class="card-title">Add New Item</h5>
        <?php $this->load->view('item/linktab'); ?>
        <?php
        if (!empty($error_messages)) {
            echo $error_messages;
        }
        ?>
        <?= $form_validation_errors; ?>
        <!-- Floating Labels Form -->
        <div class="tab-content pt-2" id="myTabjustifiedContent">
            <div class="tab-pane fade show active" id="home-justified" role="tabpanel" aria-labelledby="home-tab">
                <form action="<?php echo site_url('item/add'); ?>" method="post" role="form" autocomplete="off" enctype="multipart/form-data" class="row g-3 needs-validation" novalidate >
                    <div class="col-md-12">
                        <div class="form-floating">
                            <input type="text" name="txt_name" class="form-control" id="floatingName" placeholder="Name" value ="<?= set_value('txt_name') ?>" required>
                            <label for="floatingDetails">Name</label>
                            <div class="invalid-feedback">Please enter Item Name!</div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-floating">
                            <input type="text" name="txt_an" class="form-control" id="floatingAssetNumber" placeholder="Asset Number" value ="<?= set_value('txt_an') ?>">
                            <label for="floatingAssetNumber">Asset Number</label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-floating">
                            <input type="text" name="txt_sn" class="form-control" id="floatingSerialNumber" placeholder="Serial Number" value ="<?= set_value('txt_sn') ?>" required>
                            <label for="floatingSerialNumber">Serial Number</label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-floating">
                            <input type="text" name="txt_ar" class="form-control" id="floatingARNumber" placeholder="Asset Number" value ="<?= set_value('txt_ar') ?>">
                            <label for="floatingARNumber">AR Number</label>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-floating">
                            <textarea class="form-control" placeholder="Details" name="txt_detail" id="floatingTextarea" style="height: 100px;"><?= set_value('txt_detail'); ?></textarea>
                            <label for="floatingTextarea">Details</label>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="form-floating mb-3">
                            <select class="form-select" id="floatingSelect" aria-label="Type" name="cmb_type">
                                <option value="0">Asset</option>
                                <option value="1">Expense</option>
                            </select>
                            <label for="floatingSelect">Type</label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-floating">
                            <select class="form-select" id="floatingSelect" aria-label="Category" name="cmb_category">
                                <?php foreach ($list_category as $row) { ?>
                                    <optgroup label="<?= $row['name']; ?>">
                                        <?php foreach ($row['child'] as $rst) { ?>
                                            <option value="<?= $rst->id; ?>"><?= $rst->name; ?></option>
                                        <?php } ?>
                                    </optgroup?>
                                <?php } ?>
                            </select>
                            <label for="floatingName">Category</label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-floating">
                            <select class="form-select" id="floatingDeptResponsible" aria-label="Dept Responsible" name="cmb_dic">
                                <?php foreach ($dic as $rw) { ?>
                                    <option value="<?= $rw; ?>"><?= strtoupper($rw); ?></option>
                                <?php } ?>
                            </select>
                            <label for="floatingDeptResponsible">Dept Responsible</label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-floating">
                            <input type="date" name="txt_purchasedate" class="form-control" id="floatingPurchaseDate" placeholder="Purchase Date" value ="<?= set_value('txt_purchasedate') ?>" required>
                            <label for="floatingPurchaseDate">Purchase Date *</label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-floating mb-3">
                            <input type="file" name="img_item" class="form-control">
                            <label for="floatingSelect">Item Image <i> .jpg, .jpeg, .png</i></label>
                        </div>
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary" name="submit" value="submit">Add Item</button>
                    </div>
                </form><!-- End floating Labels Form -->
            </div>
        </div>
    </div>
</div>