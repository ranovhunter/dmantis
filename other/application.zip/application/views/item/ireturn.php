<div class="card">
    <div class="card-body">
        <h5 class="card-title">Return Item : <?= $rec_data->item_name . ' - ' . $rec_data->user_name; ?></h5>
        <?php
        echo isset($error_messages) ? $error_messages : '';
        ?>
        <!-- Floating Labels Form -->
        <div class="tab-content pt-2" id="myTabjustifiedContent">
            <div class="tab-pane fade show active" id="home-justified" role="tabpanel" aria-labelledby="home-tab">
                <form action="<?php echo site_url('item/ireturn/' . $id); ?>" method="post" role="form" autocomplete="off" enctype="multipart/form-data" class="row g-3 needs-validation" novalidate >
                    <?php if ($rec_data->location != '') { ?>
                        <div class="col-md-3">
                            <div class="form-floating mb-3">    
                                <img src="<?= LOCATION_PATH . $rec_data->location; ?>" class="img img-responsive"  height="150px"/>
                            </div>
                        </div>
                    <?php } ?>
                    <div class="col-md-4">
                        <div class="form-floating">
                            <input type="date" name="txt_return_date" class="form-control" id="floatingReturnDate" placeholder="Return Date" value ="<?= set_value('txt_return_date') ?>" required>
                            <label for="floatingPurchaseDate">Receive Date *</label>
                        </div>
                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary" name="submit" value="submit">Return Item</button>
                    </div>
                </form><!-- End floating Labels Form -->
            </div>
        </div>
    </div>
</div>