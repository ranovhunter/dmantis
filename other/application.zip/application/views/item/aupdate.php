<div class="card">
    <div class="card-body">
        <h5 class="card-title">Item Assign - <?= $rec_data->item_name . ' - ' . $rec_data->serial_number; ?></h5>
        <?php
        echo isset($error_messages) ? $error_messages : '';
        ?>
        <!-- Floating Labels Form -->
        <div class="tab-content pt-2" id="myTabjustifiedContent">
            <div class="tab-pane fade show active" id="home-justified" role="tabpanel" aria-labelledby="home-tab">
                <form action="<?php echo site_url('item/aupdate/' . $id); ?>" method="post" role="form" autocomplete="off" enctype="multipart/form-data" class="row g-3 needs-validation" novalidate >
                    <div class="col-md-6">
                        <div class="form-floating">
                            <select class="form-select" id="floatingUser" aria-label="Dept User" name="cmb_user">
                                <?php foreach ($list_user as $row) { ?>
                                    <option <?= $rec_data->user_id == $row->id ? 'selected' : ''; ?> value="<?= $row->id; ?>"><?= $row->name; ?></option>
                                <?php } ?>
                            </select>
                            <label for="floatingUser">User</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating">
                            <input type="date" name="txt_received_date" class="form-control" id="floatingPurchaseDate" placeholder="Purchase Date" value ="<?= set_value('txt_received_date', $rec_data->received_date) ?>" required>
                            <label for="floatingPurchaseDate">Receive Date *</label>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-floating">
                            <textarea class="form-control" placeholder="Details" name="txt_detail" id="floatingTextarea" style="height: 100px;"><?= set_value('txt_detail', $rec_data->detail); ?></textarea>
                            <label for="floatingTextarea">Details</label>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-floating mb-3">
                            <input type="file" name="img_loc" class="form-control">
                            <label for="floatingSelect">Item Image <i> .jpg, .jpeg, .png</i></label>
                        </div>
                    </div>
                    <?php if ($rec_data->location != '') { ?>
                        <div class="col-md-4">
                            <div class="form-floating mb-3">    
                                <img src="<?= LOCATION_PATH . $rec_data->location; ?>" class="img img-responsive"  height="250px"/>
                            </div>
                        </div>
                    <?php } ?>
                    <div class="text-center">
                        <button type="submit" class="btn btn-primary" name="submit" value="submit">Update Details</button>
                    </div>
                </form><!-- End floating Labels Form -->
            </div>
        </div>
    </div>
</div>