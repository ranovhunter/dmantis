<div class="card">
    <div class="card-body">
        <h5 class="card-title">Update Category</h5>
        <?php
        if (!empty($error_messages)) {
            echo $error_messages;
        }
        if (!empty($success_messages)) {
            echo $success_messages;
        }
        ?>
        <?= $form_validation_errors; ?>
        <!-- Floating Labels Form -->
        <form class="row g-3 needs-validation" novalidate action="<?php echo site_url('category/detail/' . $category->id); ?>" method="post" role="form" autocomplete="off">
            <div class="col-md-6">
                <div class="form-floating mb-3">
                    <select class="form-select" id="floatingSelect" aria-label="Parent Category" name="cmb_category">
                        <option selected value="0">-</option>
                        <?php foreach ($parent_category as $row) { ?>
                            <option <?= $row->id == $category->parent_id ? 'selected ' : ''; ?> value="<?= $row->id; ?>"><?= $row->name; ?></option>
                        <?php } ?>
                    </select>
                    <label for="floatingSelect">Parent Category</label>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-floating">
                    <input type="text" name="txt_name" class="form-control" id="floatingName" placeholder="Category Name" value ="<?= set_value('txt_name', $category->name) ?>" required>
                    <label for="floatingName">Category Name</label>
                    <div class="invalid-feedback">Please enter Category name!</div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="form-floating">
                    <input type="text" name="txt_detail" class="form-control" id="floatingDetails" placeholder="Category Name" value ="<?= set_value('txt_detail', $category->detail) ?>">
                    <label for="floatingDetails">Category Details</label>
                </div>
            </div>
            <div class="text-center">
                <button type="submit" class="btn btn-primary" name="update" value="update">Update Category</button>
            </div>
        </form><!-- End floating Labels Form -->

    </div>
</div>