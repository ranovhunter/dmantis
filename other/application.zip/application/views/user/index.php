<div class="card">
    <div class="card-body">
        <h5 class="card-title">List User</h5>

        <!-- Table with hoverable rows -->
        <div class="table-responsive">
            <table class="table table-hover table-bordered">
                <thead>
                    <tr>
                        <th scope="col" class="text-center">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Department</th>
                        <th scope="col">Email</th>
                        <th scope="col"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($list_user)) { ?>
                        <tr>
                            <td colspan="3"><i>No User Registered</i></td>
                        </tr>
                        <?php
                    } else {
                        ?>
                        <?php
                        $i = 1;
                        foreach ($list_user as $row) {
                            ?>
                            <tr>
                                <td class="text-center"><?= $i++; ?></td>
                                <td><?= ucfirst($row->name); ?></td>
                                <td><?= strtoupper($row->department_name); ?></td>
                                <td><?= $row->email; ?></td>
                                <td class="text-center">
                                    <a href="<?php echo site_url('user/asset/' . $row->id); ?>" type="button" class="btn btn-primary"><i class="bi bi-card-list me-1"></i> View Asset</a>
                                </td>
                            </tr>
                            <?php
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <!-- End Table with hoverable rows -->
    </div>
</div>