<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config['google_client_id']="1040271647714-lgabsnvpl4pfgm4nf596ma7sbfm3pvt0.apps.googleusercontent.com";
$config['google_client_secret']="BTMYJc7WTB1T9BqKfs_22oV6";
$config['google_redirect_url']=base_url().'home/registergmail';

