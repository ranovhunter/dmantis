<?php

defined('BASEPATH') or exit('No direct script access allowed');

/**
 *  Stocktake
 *
 *  @author Hunter Ninggolan
 *  @date March 16th, 2015
 */
class Stocktake extends MY_Controller {

    function __construct() {
        parent::__construct();
        $this->is_logged();
        $this->layout_dir = 'layout/';
        $this->page_dir = 'stocktake/';
        $this->load->model('stocktake_model', 'stocktake');
        $this->load->model('stocktake_detail_model', 'stocktake_detail');
        $this->load->model('item_model', 'item');
    }

    function index() {
        $this->data ['page_icon'] = 'icomoon-icon-list';
        $this->data ['page_title'] = 'Administration';
        $this->data ['page_icon'] = 'icomoon-icon-list';
        $this->data ['page_title'] = 'Daftar Category';
        $list_data = array();
        $stocktake_data = $this->stocktake->get_data();
        foreach ($stocktake_data as $row) {
            $list_data[$row->id]['id'] = $row->id;
            $list_data[$row->id]['start_date'] = $row->start_date;
            $list_data[$row->id]['start_user'] = $row->start_user;
            $list_data[$row->id]['s_user_name'] = $row->s_user_name;
            $list_data[$row->id]['end_date'] = $row->end_date;
            $list_data[$row->id]['end_user'] = $row->end_user;
            $list_data[$row->id]['e_user_name'] = $row->e_user_name;
            $list_data[$row->id]['status'] = $row->status;
            $st_total = $this->stocktake_detail->get_data('id', array('stock_take_id' => $row->id));
            $st_close = $this->stocktake_detail->get_data('id', array('stock_take_id' => $row->id, 'is_checked' => 1));
            $list_data[$row->id]['total_item'] = count($st_total);
            $list_data[$row->id]['close_item'] = count($st_close);
        }
        $this->data ['list_data'] = $list_data;
        $this->data ['page'] = $this->load->view($this->get_page(), $this->data, true);
        $this->render();
    }

    function create() {
        $is_active = $this->stocktake->get_data('id', array('status' => 1));
        if ($is_active == array()) {
            $data = array(
                'start_user' => $this->session->userdata('sess-id'),
                'start_date' => date("Y-m-d H:i:s")
            );
            if ($this->stocktake->add_data($data)) {
                $stocktake_id = $this->stocktake->insert_id;
                $item_data = $this->item->get_active();
                foreach ($item_data as $row) {
                    $item['stock_take_id'] = $stocktake_id;
                    $item['item_id'] = $row['id'];
                    $item['item_qrcode'] = $row['qrcode'];
                    $this->stocktake_detail->add_data($item);
                }
                redirect(site_url('stocktake/detail/' . $stocktake_id));
            } else {
                $this->data ['error_messages'] = get_messages('Failed to add Category');
            }
        } else {
            $this->session->set_flashdata('info_messages', "Can't create Stock Take Event. Please close other open Stock Take Event");
            redirect(site_url('stocktake'));
        }
    }

    function close() {
        $this->data['id'] = $this->uri->segment(3);
        $st_open = $this->stocktake_detail->get_data('id', array('stock_take_id' => $this->data['id'], 'is_checked' => 0));
        if ($st_open == array()) {
            $data = array(
                'end_user' => $this->session->userdata('sess-id'),
                'end_date' => date("Y-m-d H:i:s")
            );
            if ($this->stocktake->add_data($data)) {
                $this->session->set_flashdata('info_messages', "Successfully close Stock Take Event.");
                redirect(site_url('stocktake/' . $stocktake_id));
            } else {
                $this->data ['error_messages'] = get_messages('Failed to add Category');
            }
        } else {
            $this->session->set_flashdata('info_messages', "Can't Close Stock Take Event. Please complete all item stock take");
            redirect(site_url('stocktake'));
        }
    }

    function scan() {
        if ($this->input->post('scan')) {
            $data = $this->stocktake_detail->get_data(array('id', 'is_checked'), array('item_qrcode' => $this->input->post('tx_scan')), null, null, null, null, 'row');
            redirect(site_url('stocktake/check/' . $data->id));
        } else {
            redirect(site_url('stocktake'));
        }
    }

    function detail() {
        $this->data['id'] = $this->uri->segment(3);
        $this->data['page'] = $this->uri->rsegment(4, 1);
        $this->data['offset'] = get_offset($this->data['page'], $this->data['max_rows']);
        $this->data ['page_icon'] = 'icomoon-icon-plus';
        $this->data ['page_title'] = 'Update user';
        $this->data ['list_data'] = $this->stocktake_detail->get_data(null, array('stock_take_id' => $this->data['id']), $this->data['max_rows'], $this->data['offset']);
        $this->data['pagination'] = $this->build_pagination(site_url() . '/stocktake/detail/' . $this->data['id'] . '/', $this->uri->total_segments(), $this->stocktake_detail->total_rows, $this->data['max_rows'], $this->data['numlinks']);
        $this->data ['page'] = $this->load->view($this->get_page('detail'), $this->data, true);
        $this->render();
    }

    function check() {
        $this->data['id'] = $this->uri->segment(3);
        $this->data ['page_icon'] = 'icomoon-icon-plus';
        $this->data ['page_title'] = 'Update user';
        $this->data ['rec_data'] = $this->stocktake_detail->get_data(null, array('id' => $this->data['id']), null, null, null, null, 'row');
        if ($this->input->post('submit')) {
            $this->form_validation->set_rules('txt_location', 'Location', 'trim|xss_clean|required');
            $this->form_validation->set_rules('cmb_status', 'Status', 'trim|xss_clean|required');
            $this->form_validation->set_rules('cmb_condition', 'Condition', 'trim|xss_clean|required');

            if ($this->form_validation->run() == TRUE) {
                $data = array(
                    'status' => $this->input->post('cmb_status'),
                    'condition' => $this->input->post('cmb_condition'),
                    'location' => $this->input->post('txt_location'),
                    'check_user' => $this->session->userdata('sess-id'),
                    'check_date' => date("Y-m-d H:i:s"),
                    'is_checked' => 1
                );
                $config = array(
                    'upload_path' => UPLOAD_PATH_ITEM,
                    'allowed_types' => 'jpg|jpeg|png',
                    'overwrite' => true,
                    'remove_spaces' => true
                );
                $this->load->library('upload', $config);
                if ($this->upload->do_upload('img_item')) {
                    $uploaddata = $this->upload->data();
                    $info = pathinfo($_FILES ['img_item'] ['name']);
                    $rawname = 'ST_ITM' . date('ymdHis');
                    $data['picture'] = $rawname . '.' . $info ['extension'];
                    rename($uploaddata ['full_path'], $uploaddata ['file_path'] . $data['picture']);
                    if ($this->stocktake_detail->edit_data($data, array('id' => $this->data['id']))) {
                        $this->session->set_flashdata('info_messages', 'Inventory  successfully checked ');
                        redirect(site_url('stocktake/detail/' . $this->data ['rec_data']->stock_take_id));
                    } else {
                        $this->session->set_flashdata('err_messages', 'Failed to Check Inventory. Please Try again, or contact system administrator');
                        redirect(site_url('stocktake/check/' . $this->data['id']));
                    }
                } else {
                    $this->data ['error_messages'] = get_messages("Failed to upload picture");
                }
            } else {
                $this->data ['error_messages'] = validation_errors() ? get_messages(validation_errors()) : '';
            }
        }
        $this->data ['page'] = $this->load->view($this->get_page('check'), $this->data, true);
        $this->render();
    }

    public function delete() {
        if ($this->data['userdata']['sess-role'] == 2)
            redirect('home');
        $param = $this->uri->uri_to_assoc(4);
        $key_update = '';
        if (!empty($param ['id'])) {
            $key_update = $param ['id'];
        }
        if ($this->admin->delete_data(array(
                    'id' => $key_update
                ))) {
            redirect('admin/modules');
        } else {
            $this->data ['messages'] = 'Data Gagal di Hapus';
        }
    }

}

/**
 * End of file stocktake.php
 * Location : ./application/controllers/stocktake.php
 */