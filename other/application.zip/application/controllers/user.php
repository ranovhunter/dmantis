<?php

defined('BASEPATH') or exit('No direct script access allowed');

/**
 *  Dashboar
 *
 *  @author Hunter Ninggolan
 *  @date June 10th, 2019
 */
class User extends MY_Controller {

    function __construct() {
        parent::__construct();
        $this->is_logged();
        $this->layout_dir = 'layout/';
        $this->page_dir = 'user/';
        $this->data['menu'] = 'user';
        $this->data['active_menu'] = 'dashboard';
        $this->data['mainData'] = null;
        $this->data['ishome'] = true;
    }

    function index() {
        $this->data ['page_icon'] = 'icomoon-icon-list';
        $this->data ['page_title'] = 'MY Request Info';
        $this->load->model('user_model', 'muser');
        $this->data['list_user'] = $this->muser->get_data();

        $this->data ['page'] = $this->load->view($this->get_page(), $this->data, true);
        $this->render();
    }

    function asset() {
        $this->data['userid'] = $this->uri->segment(3);
        $this->data ['page_icon'] = 'icomoon-icon-list';
        $this->data ['page_title'] = 'MY Request Info';
        $this->load->model('user_item_model', 'user_item');
        $this->data['list_item'] = $this->user_item->get_data(null, array('user_id' => $this->data['userid']));
        $this->data ['page'] = $this->load->view($this->get_page('asset'), $this->data, true);
        $this->render();
    }

}

/**
 * End of file home.php
 * Location : ./application/controllers/home.php
 */