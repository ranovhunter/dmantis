<?php

defined('BASEPATH') or exit('No direct script access allowed');

/**
 *  Vendor
 *
 *  @author Hunter Ninggolan
 *  @date March 16th, 2015
 */
class Vendor extends MY_Controller {

    function __construct() {
        parent::__construct();
        $this->is_admin_login();
        $this->layout_dir = 'layout/';
        $this->page_dir = 'vendor/';
        $this->load->model('vendor_model', 'vendor');
    }

    function index() {
		$this->data ['enable_search'] = true;
        $this->data ['action_search'] = site_url('vendor/index/');
		if($this->input->post('search')){
			redirect(site_url('vendor/search/'.str_rot13($this->input->post('tx_search'))));
		}
        $page = $this->uri->rsegment(3, 0);
        $this->data['offset'] = get_offset($page, $this->data['max_rows']);
        $this->data ['curr_poss'] = 'new';
        $this->data ['page_icon'] = 'icomoon-icon-list';
        $this->data ['page_icon'] = 'icomoon-icon-list';
        $this->data ['page_title'] = 'List Vendors';
        $this->data ['list_vendor'] = $this->vendor->get_data(null, null, $this->data['max_rows'], $this->data['offset']);
        $this->data['pagination'] = $this->build_pagination(site_url() . '/vendor/index/', $this->uri->total_segments(), $this->vendor->total_rows, $this->data['max_rows'], $this->data['numlinks']);
        $this->data ['page'] = $this->load->view($this->get_page(), $this->data, true);
        $this->render();
    }

    function reset() {
        $id = $this->uri->segment(3);
        $vendor = $this->vendor->get_data('id,name', array('id' => $id), null, null, null, null, 'row');
        if ($this->vendor->edit_data(array('password' => sha1($id)), array('id' => $id))) {
            $this->session->set_flashdata('info_messages', $vendor->name . ' Password has successfully Reset');
        } else {
            $this->session->set_flashdata('err_messages', 'Send Error. Please Try again, or contact system administrator');
        }
        redirect(site_url('vendor'));
    }
	function search() {
		$this->data ['enable_search'] = true;
        $this->data ['action_search'] = site_url('vendor/index/');
        $this->data['keyword'] = str_rot13($this->uri->rsegment(3, 0));
        $page = $this->uri->rsegment(4, 0);
        $this->data['offset'] = get_offset($page, $this->data['max_rows']);
        $this->data ['curr_poss'] = 'new';
        $this->data ['page_icon'] = 'icomoon-icon-list';
        $this->data ['page_title'] = 'Purchasing - Index';
        $this->data ['page_icon'] = 'icomoon-icon-list';
        $this->data ['page_title'] = 'Daftar Users';
        $this->data ['list_vendor'] = $this->vendor->get_search($this->data['keyword'], $this->data['max_rows'], $this->data['offset']);
        $this->data['pagination'] = $this->build_pagination(site_url() . '/vendor/search/'.str_rot13($this->data['keyword']), $this->uri->total_segments(), $this->vendor->total_rows, $this->data['max_rows'], $this->data['numlinks']);
        $this->data ['page'] = $this->load->view($this->get_page('search'), $this->data, true);
        $this->render();
    }

}

/**
 * End of file vendor.php
 * Location : ./application/controllers/vendor.php
 */