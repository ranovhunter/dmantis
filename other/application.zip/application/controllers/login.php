<?php

defined('BASEPATH') or exit('No direct script access allowed');

class Login extends MY_Controller {

    function __construct() {
        parent::__construct();
        $this->layout_dir = 'layout/login/';
        $this->page_dir = 'login/';
        if ($this->session->userdata('sess-loggedin')) {
            redirect(site_url());
        }
    }

    function index() {
        if ($this->input->post('submit')) {
            $this->form_validation->set_error_delimiters("<li>", "</li>");
            $this->form_validation->set_rules('email', 'Email', 'trim|xss_clean|required|valid_email');
            $this->form_validation->set_rules('password', 'Password', 'required|xss_clean');
            if ($this->form_validation->run()) {
                $this->load->model('user_model', 'muser');
                $rec_user = $this->muser->get_data(null, array('email' => $this->input->post('email')), null, null, null, null, 'row');
                if ($this->muser->total_rows == 1) {
                    if (sha1($_POST ['password']) == $rec_user->password) {
                        //$acl = $this->user_method->get_data(null, array('user_id' => $rec_user->id));
                        $acl = $this->user_method->get_all_method(3, $rec_user->id);
                        //exit();
                        if ($acl == array()) {
                            $this->data ['form_validation_errors'] = wrap_text('Your don\'t any privilage to access the System. Please ask system Administrator');
                        } else {
                            //debug($rec_user);exit();
                            $this->session->set_userdata(array(
                                'sess-id' => $rec_user->id,
                                'sess-email' => $rec_user->email,
                                'sess-name' => $rec_user->name,
                                'sess-role' => $rec_user->roles_id,
                                'sess-dept' => $rec_user->department_id,
                                'sess-deptname' => $rec_user->department_name,
                                'sess-role-name' => $rec_user->roles_name,
                                'sess-loggedin' => true,
                                'is_admin' => true,
                                //'acl' => $acl,
                                'sess-starttime' => date('Y-m-d H:i:s')
                            ));
                            redirect(site_url('dashboard'));
                        }
                    } else {
                        //$kkk = md5($_POST ['password']);
                        $this->data ['form_validation_errors'] = wrap_text('Your password doesn\'t match');
                    }
                } else {
                    $this->data ['form_validation_errors'] = wrap_text('Your Email is not Registered');
                }
            } else {
                $this->data ['form_validation_errors'] = validation_errors();
            }
        }
        $this->data ['html_title'] = 'Administration Login';
        $this->data ['page'] = $this->load->view($this->get_page(), $this->data, true);
        $this->render();
    }

}

/**
 * End of file login.php
 * Location : ./application/controllers/login.php
 */