<?php

defined('BASEPATH') or exit('No direct script access allowed');

/**
 *  Category
 *
 *  @author Hunter Ninggolan
 *  @date March 16th, 2015
 */
class Category extends MY_Controller {

    function __construct() {
        parent::__construct();
        $this->is_logged();
        $this->layout_dir = 'layout/';
        $this->page_dir = 'category/';
        $this->load->model('category_model', 'category');
        $this->data ['parent_category'] = $this->category->get_data(null,array('parent_id'=>0));
    }

    function index() {
        $this->data ['page_icon'] = 'icomoon-icon-list';
        $this->data ['page_title'] = 'Administration';
        $this->data ['page_icon'] = 'icomoon-icon-list';
        $this->data ['page_title'] = 'Daftar Category';
        $this->data ['list_category'] = $this->category->get_all_cat();
        $this->data ['page'] = $this->load->view($this->get_page(), $this->data, true);
        $this->render();
    }

    function add() {
        $this->data ['page_icon'] = 'icomoon-icon-list';
        $this->data ['page_title'] = 'Administration';
        $this->data ['page_icon'] = 'icomoon-icon-list';
        if ($this->input->post('submit')) {
            $this->form_validation->set_rules('txt_name', 'Category Name', 'trim|xss_clean|required');
            $this->form_validation->set_rules('txt_detail', 'Category Detail', 'trim|xss_clean');
            $this->form_validation->set_rules('cmb_category', 'Parent Category', 'trim|xss_clean');
            
            if ($this->form_validation->run() == TRUE) {
                $data = array(
                    'parent_id' => $this->input->post('cmb_category'),
                    'name' => $this->input->post('txt_name'),
                    'detail' => $this->input->post('txt_detail'),
                    'insert_user' => $this->session->userdata('sess-id'),
                    'insert_date' => date("Y-m-d H:i:s")
                );

                if ($this->category->add_data($data)) {
                    redirect('category');
                } else {
                    $this->data ['error_messages'] = get_messages('Failed to add Category');
                }
            } else {
                $this->data ['error_messages'] = validation_errors() ? get_messages(validation_errors()) : '';
            }
        }
        $this->data ['page'] = $this->load->view($this->get_page('add'), $this->data, true);
        $this->render();
    }

    function detail() {
        $this->data['id'] = $this->uri->segment(3);
        if ($this->input->post('update')) {
            $this->form_validation->set_rules('txt_name', 'Category Name', 'trim|xss_clean|required');
            $this->form_validation->set_rules('txt_detail', 'Category Detail', 'trim|xss_clean');
            $this->form_validation->set_rules('cmb_category', 'Parent Category', 'trim|xss_clean');
            
            if ($this->form_validation->run() == TRUE) {
                $data = array(
                    'parent_id' => $this->input->post('cmb_category'),
                    'name' => $this->input->post('txt_name'),
                    'detail' => $this->input->post('txt_detail'),
                    'update_user' => $this->session->userdata('sess-id'),
                    'update_date' => date("Y-m-d H:i:s")
                );

                if ($this->category->edit_data($data, array('id' => $this->data['id']))) {
                    redirect('category');
                } else {
                    $this->data ['error_messages'] = get_messages('Gagal Mengupdate Data kategori Ini');
                }
            } else {
                $this->data ['error_messages'] = validation_errors() ? get_messages(validation_errors()) : '';
            }
        }
        $this->data ['category'] = $this->category->get_data(null, array('id' => $this->data['id']), null, null, null, null, 'row');
        $this->data ['page_icon'] = 'icomoon-icon-plus';
        $this->data ['page_title'] = 'Update user';

        $this->data ['page'] = $this->load->view($this->get_page('detail'), $this->data, true);
        $this->render();
    }

    public function delete() {
        if ($this->data['userdata']['sess-role'] == 2)
            redirect('home');
        $param = $this->uri->uri_to_assoc(4);
        $key_update = '';
        if (!empty($param ['id'])) {
            $key_update = $param ['id'];
        }
        if ($this->admin->delete_data(array(
                    'id' => $key_update
                ))) {
            redirect('admin/modules');
        } else {
            $this->data ['messages'] = 'Data Gagal di Hapus';
        }
    }

}

/**
 * End of file modules.php
 * Location : ./application/controllers/modules.php
 */